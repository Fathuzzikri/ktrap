@extends('adminlte::page')

@section('title', 'K-TRAP Stats')

@section('content_header')
    <h1>STATISTIK</h1>
@stop

@section('content')
    <p>Halaman Statistik Serangan dan Aktivitas</p>
@stop