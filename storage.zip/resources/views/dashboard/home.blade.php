@extends('adminlte::page')

@section('title', 'K-TRAP Home')

@section('content_header')
    <h1>Dashboard</h1>
@stop

@section('content')
    <p>Halaman Statistik Umum Server</p>
@stop