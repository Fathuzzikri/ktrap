<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DetailSerangan extends Model
{
    //
    protected $table = 'input';
}
